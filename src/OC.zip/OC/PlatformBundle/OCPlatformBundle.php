<?php

namespace OC\PlatformBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class OCPlatformBundle extends Bundle
{
}
